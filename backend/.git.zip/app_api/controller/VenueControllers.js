var mongoose=require('mongoose');
var Venue=mongoose.model('venue');

const createResponse=function(res,status,content){
    res.status(status).json(content);
}

const listVenues=function(req,res){
    createResponse(res,200,{"status":"success"});
}
const addVenues=function(req,res){
    createResponse(res,200,{"status":"success"});
}
const getVenues=function(req,res){
    createResponse(res,200,{"status":"success"});
}
const updateVenue=function(req,res){
    createResponse(res,200,{"status":"success"});
}
const deleteVenue=function(req,res){
    createResponse(res,200,{"status":"success"});
}

module.exports={
    listVenues,
    addVenues,
    getVenues,
    updateVenue,
    deleteVenue
}